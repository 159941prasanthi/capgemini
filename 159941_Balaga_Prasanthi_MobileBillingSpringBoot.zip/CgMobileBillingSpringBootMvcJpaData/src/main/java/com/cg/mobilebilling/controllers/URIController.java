package com.cg.mobilebilling.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.mobilebilling.beans.Customer;


@Controller
public class URIController {
	Customer customer;
	@RequestMapping("/")
	public String getIndexPage(){
		return "indexPage";
	}
	@RequestMapping("/indexPage")
	public String getIndexPage1(){
		return "indexPage";
	}
	@RequestMapping("/registerCustomer")
	public String registerCustomerPage() {
		return "registerCustomerPage";
	}
	@RequestMapping("/createPostpaidAccount")
	public String createPostpaidAccountPage() {
		return "createPostpaidAccountPage";
	}
	@RequestMapping("/generateMobileMonthlyBill")
	public String generateMobileBillPage() {
		return "generateMobileBillPage";
	}
	@RequestMapping("/getParticularCustomerDetails")
	public String getCustomerDetailsPage() {
		return "getCustomerDetailsPage";
	}
	@RequestMapping("/getParticularPostpaidAccountDetails")
	public String getPostpaidAccountDetailsPage() {
		return "getPostpaidAccountDetailsPage";
	}
	@RequestMapping("/getCustomerAllPostpaidAccountDetails")
	public String getCustomerAllPostpaidAccountDetailsPage() {
		return "getCustomerAllPostpaidAccountDetailsPage";
	}
	@RequestMapping("/getMobileBillDetails")
	public String getMobileBillDetailsPage() {
		return "getMobileBillDetailsPage";
	}
	@RequestMapping("/getMobileAllBillDetails")
	public String getMobileAllBillDetailsPage() {
		return "getMobileAllBillDetailsPage";
	}
	@RequestMapping("/changePlanForMobileNumber")
	public String changePlanPage() {
		return "changePlanPage";
	}
	@RequestMapping("/getCustomerPostPaidAccountPlanDetails")
	public String getCustomerPostPaidAccountPlanPage() {
		return "getCustomerPostPaidAccountPlanPage";
	}
	@RequestMapping("/deleteCustomerDetails")
	public String deleteCustomerDetailsPage() {
		return "deleteCustomerPage";
	}
	@RequestMapping("/closeCustomerPostPaidAccountDetails")
	public String closePostPaidAccountDetails() {
		return "closePostPaidPage";
	}
	@ModelAttribute
	public Customer getCustomer() {
		customer=new Customer();
		return customer;
	}
}
