package com.cg.mobilebilling.services;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.BillingDAOServices;
import com.cg.mobilebilling.daoservices.CustomerDAOServices;
import com.cg.mobilebilling.daoservices.PlanDAOServices;
import com.cg.mobilebilling.daoservices.PostpaidDAOServices;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
@Component("billingServices")
public class BillingServicesImpl implements BillingServices {
	@Autowired
	BillingDAOServices billingDAO;
	@Autowired
	CustomerDAOServices customerDAO;
	@Autowired
	PlanDAOServices planDAO;
	@Autowired
	PostpaidDAOServices postpaidDAO;
	@Override
	public List<Plan> getPlanAllDetails() throws BillingServicesDownException {
		List<Plan> plan=planDAO.findAll();
		if(plan==null) throw new BillingServicesDownException("Sorry billing services down");
		return plan;
	}
	@Override
	public Customer acceptCustomerDetails(Customer customer) throws BillingServicesDownException {
		customerDAO.save(customer);
		acceptPlanDetails();
		if(customer==null) throw new BillingServicesDownException("Sorry billing services down");
		return customer;
	}
	@Override
	public long openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer details not found for customer "+customerID));;
		Plan plan=planDAO.findById(planID).orElseThrow(()->new PlanDetailsNotFoundException("Plan details not found for the particular ID"));
		PostpaidAccount postpaid=new PostpaidAccount(plan, customer);
		postpaidDAO.save(postpaid);
		return postpaid.getMobileNo();
	}
	@Override
	public Bill generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
					throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
					BillingServicesDownException, PlanDetailsNotFoundException {
		Customer customer= customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer details not found for customer "+customerID));
		PostpaidAccount postpaidAccount=postpaidDAO.getPostPaidAccountDetails(customer, mobileNo);
		if(postpaidAccount==null) throw new PostpaidAccountNotFoundException("postpaid account details not found");
		Bill bill=billingDAO.getMobileBillDetails(postpaidAccount, billMonth);
		if(bill!=null) throw new BillingServicesDownException("Sorry bill for this month already exists");
		bill=new Bill(noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits, postpaidAccount, billMonth);
		if(noOfLocalSMS>postpaidAccount.getPlan().getFreeLocalSMS())
			bill.setLocalSMSAmount((noOfLocalSMS-postpaidAccount.getPlan().getFreeLocalSMS())*postpaidAccount.getPlan().getLocalSMSRate());
		else
			bill.setLocalSMSAmount(0);
		if(noOfStdSMS>postpaidAccount.getPlan().getFreeStdSMS())
			bill.setStdSMSAmount((noOfStdSMS-postpaidAccount.getPlan().getFreeStdSMS())*postpaidAccount.getPlan().getStdSMSRate());
		else
			bill.setStdSMSAmount(0);
		if(noOfLocalCalls>postpaidAccount.getPlan().getFreeLocalCalls())
			bill.setLocalCallAmount((noOfLocalCalls-postpaidAccount.getPlan().getFreeLocalCalls())*postpaidAccount.getPlan().getLocalCallRate());
		else
			bill.setLocalCallAmount(0);
		if(noOfStdCalls>postpaidAccount.getPlan().getFreeStdCalls())
			bill.setStdCallAmount((noOfStdCalls-postpaidAccount.getPlan().getFreeStdCalls())*postpaidAccount.getPlan().getStdCallRate());
		else
			bill.setStdCallAmount(0);
		if(internetDataUsageUnits>postpaidAccount.getPlan().getFreeInternetDataUsageUnits())
			bill.setInternetDataUsageAmount((internetDataUsageUnits-postpaidAccount.getPlan().getFreeInternetDataUsageUnits())*postpaidAccount.getPlan().getInternetDataUsageRate());
		else
			bill.setInternetDataUsageAmount(0);
		float intialamount=bill.getLocalSMSAmount()+bill.getLocalCallAmount()+bill.getStdSMSAmount()+bill.getStdCallAmount()+bill.getInternetDataUsageAmount()+postpaidAccount.getPlan().getMonthlyRental();
		bill.setCgst((intialamount*3)/100);
		bill.setSgst((intialamount*3)/100);
		bill.setTotalBillAmount(intialamount+bill.getCgst()+bill.getSgst());
		billingDAO.save(bill);
		return bill;
	}
	@Override
	public Customer getCustomerDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer= customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer details not found for customer "+customerID));
		return customer;
	}
	@Override
	public List<Customer> getAllCustomerDetails() throws BillingServicesDownException {
		List<Customer> customer=customerDAO.findAll();
		if(customer==null) throw new BillingServicesDownException("Sorry billing services down");
		return customer;
	}
	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer details not found for customer "+customerID));
		PostpaidAccount postpaid=postpaidDAO.getPostPaidAccountDetails(customer, mobileNo);
		if(postpaid==null) throw new PostpaidAccountNotFoundException("postpaid account not found.");
		return postpaid;
	}
	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer details not found for customer "+customerID));
		List<PostpaidAccount> postpaid=new ArrayList<>();
		postpaid=postpaidDAO.getCustomerAllPostpaidAccountsDetails(customer);
		return postpaid;
	}
	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer details not found for customer "+customerID));
		PostpaidAccount postpaid=postpaidDAO.getPostPaidAccountDetails(customer, mobileNo);
		if(postpaid==null)throw new PostpaidAccountNotFoundException("postpaid account not found for this account");
		Bill bill=billingDAO.getMobileBillDetails(postpaid ,billMonth);
		if(bill==null) throw new InvalidBillMonthException("Enter valid billing month");
		return bill;
	}
	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			BillDetailsNotFoundException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer details not found for customer "+customerID));
		PostpaidAccount postpaid=postpaidDAO.getPostPaidAccountDetails(customer, mobileNo);
		if(postpaid==null)throw new PostpaidAccountNotFoundException("postpaid account not found for this account");
		List<Bill> bill=new ArrayList<>();
		bill=postpaidDAO.getCustomerPostPaidAccountAllBillDetails(customer, mobileNo);
		if(bill==null) throw new BillDetailsNotFoundException("bill details not found exception");
		return bill;
	}
	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID) throws CustomerDetailsNotFoundException,
	PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer details not found for customer "+customerID));
		PostpaidAccount postpaid=getPostPaidAccountDetails(customerID, mobileNo);
		if(postpaid==null) throw new PostpaidAccountNotFoundException("postpaid account details not found for "+mobileNo);
		Plan plan=planDAO.findById(planID).orElseThrow(()->new PlanDetailsNotFoundException("Plan details not found for the particular ID"));
		postpaid=new PostpaidAccount(mobileNo, plan, customer);
		postpaidDAO.save(postpaid);
		return true;
	}
	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer details not found for customer "+customerID));
		PostpaidAccount postpaid=getPostPaidAccountDetails(customerID, mobileNo);
		if(postpaid==null) throw new PostpaidAccountNotFoundException("postpaid account details not found for "+mobileNo);
		billingDAO.deleteAllBills(postpaid);
		postpaidDAO.closeCustomerPostPaidAccount(customer, mobileNo);
		return true;
	}
	@Override
	public boolean deleteCustomer(int customerID)
			throws BillingServicesDownException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer details not found for customer "+customerID));
		ArrayList<PostpaidAccount>postpaidAccounts=(ArrayList<PostpaidAccount>) getCustomerAllPostpaidAccountsDetails(customerID);
		for(PostpaidAccount postpaidAccount:postpaidAccounts) {
			closeCustomerPostPaidAccount(customerID, postpaidAccount.getMobileNo());			
		}
		customerDAO.deleteById(customerID);
		return true;
	}
	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			PlanDetailsNotFoundException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer details not found for customer "+customerID));
		PostpaidAccount postpaid=getPostPaidAccountDetails(customerID, mobileNo);
		if(postpaid==null) throw new PostpaidAccountNotFoundException("postpaid account details not found for "+mobileNo);
		Plan plan=postpaid.getPlan();
		if(plan==null) throw new PlanDetailsNotFoundException("plan details not found");
		return plan;
	}
	@Override
	public void acceptPlanDetails() throws BillingServicesDownException {
		Plan plan1=new Plan(1, 50, 50, 20, 200, 50, 50, 0.3f, 0.5f, 0.2f, 0.7f,3, "Mumbai", "Nestham");
		planDAO.save(plan1);
		Plan plan2=new Plan(2, 60, 52, 21, 240, 55, 70, 0.3f, 0.5f, 0.2f, 0.7f, 4, "Pune", "Amulya");
		planDAO.save(plan2);
		Plan plan3=new Plan(3, 75, 58, 25, 300, 60, 50, 0.3f, 0.5f, 0.2f, 0.7f, 5, "Mumbai-Pune", "Golden");
		planDAO.save(plan3);
		
	}
}